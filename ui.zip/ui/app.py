# ui/app.py
import streamlit as st
from streamlit_option_menu import option_menu

# Import UI pages — use package imports. If run without PYTHONPATH set,
# Streamlit may import this file as a top-level script and package imports might fail.
# We add a fallback to relative imports if absolute package import fails.
try:
    from pages import dashboard, news, portfolio, orders, history
except Exception:
    # fallback (if you run streamlit from ui folder and package root isn't in PYTHONPATH)
    from ui.pages import dashboard, news, portfolio, orders, history

st.set_page_config(page_title="Stocker AI", layout="wide")

with st.sidebar:
    choice = option_menu(
        "Stocker AI",
        ["Dashboard", "Portfolio", "Orders", "History", "News"],
        icons=["bar-chart", "wallet", "receipt", "clock", "newspaper"],
        menu_icon="robot",
        default_index=0
    )

if choice == "Dashboard":
    dashboard.render()
elif choice == "Portfolio":
    portfolio.render()
elif choice == "Orders":
    orders.render()
elif choice == "History":
    history.render()
elif choice == "News":
    news.render()
