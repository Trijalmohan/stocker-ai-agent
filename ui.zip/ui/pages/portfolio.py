import streamlit as st

def render():
    st.title("💼 Portfolio")
    st.write("Portfolio page stub — filled soon.")
