import streamlit as st
from ui.services.api_client import call_backend

def render():
    st.title("📰 Market News")
    st.write("Live market headlines from global financial sources.")

    trace, response, error = call_backend(
        message="get market news",
        intent="market_news"
    )

    if error:
        st.error(error)
        return

    news_list = response.get("news", [])

    if not news_list:
        st.info("No news available.")
        return

    for article in news_list:
        st.markdown(f"""
        ### 🔹 {article['title']}
        **Source:** {article['source']}  
        **Published:** {article['pubDate']}  

        [Read full article]({article['link']})
        ---
        """)
