# ui/pages/backtest.py

import streamlit as st
from src.services.backtest import backtest


def render():
    st.title("📉 Backtesting Engine")

    symbol = st.text_input("Symbol", "AAPL").upper()

    if st.button("Run Backtest"):
        result = backtest(symbol)

        if "error" in result:
            st.error(result["error"])
        else:
            st.success("Backtest Completed")
            st.json(result)
