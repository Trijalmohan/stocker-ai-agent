# ui/pages/charts.py
"""
Streamlit page: Charts / Indicators

This page asks backend for a preformatted time-series for a symbol
and renders a candlestick + selected indicator overlays (SMA/EMA/Bollinger)
and a small RSI + MACD panel below.

Requires backend endpoint /api/handle to support intent 'indicator_series' OR
'analyze' that returns 'indicators' with a 'series' key. We'll call with intent
'indicator_series' first, then fallback to 'analyze'.
"""

import streamlit as st
import pandas as pd
import altair as alt
from ui.services.api_client import call_backend

st.set_page_config(page_title="Charts", layout="wide")


def fetch_series(symbol: str, period: str = "6mo"):
    """
    Try to fetch preformatted series via backend.
    Expected backend response shape:
    {
      "status": "ok",
      "symbol": "BTC",
      "indicators": {
        "cache_source": "fresh"|"cached",
        "raw_period": "6mo",
        "series": [ {date, close, sma20, sma50, ema12, ema26, bb_mid, bb_upper, bb_lower, rsi, macd, signal, histogram}, ... ]
      }
    }
    """
    # Prefer specific endpoint intent
    trace, resp, err = call_backend(
        message=f"get indicator series for {symbol} period {period}",
        intent="indicator_series"
    )
    if err:
        # fallback to analyze which should include indicators.series in some setups
        trace, resp, err = call_backend(
            message=f"Analyze {symbol}",
            intent="analyze"
        )
        if err:
            return None, None, err

    # normalize
    indicators = resp.get("indicators") if isinstance(resp, dict) else None
    if not indicators:
        return None, None, "Backend returned no indicators."

    series = indicators.get("series") or indicators.get("time_series") or indicators.get("chart") or []
    cache_source = indicators.get("cache_source", "unknown")
    return series, cache_source, None


def render_chart(df: pd.DataFrame):
    """
    Render candlestick + overlays using Altair
    """
    base = alt.Chart(df).encode(x='date:T')

    # Candles (we simulate using open/high/low/close if available; else use close line)
    if {"open", "high", "low", "close"}.issubset(df.columns):
        # rule for wick
        wick = base.mark_rule().encode(
            y='low:Q',
            y2='high:Q',
            color=alt.condition("datum.close > datum.open", alt.value("#06982d"), alt.value("#ae1325"))
        )
        bar = base.mark_bar().encode(
            y='open:Q',
            y2='close:Q',
            color=alt.condition("datum.close > datum.open", alt.value("#06982d"), alt.value("#ae1325"))
        )
        chart = (wick + bar).interactive()
    else:
        chart = base.mark_line().encode(y='close:Q').interactive()

    # overlays: sma20, sma50, ema12, ema26
    overlays = []
    for name in ("sma20", "sma50", "ema12", "ema26"):
        if name in df.columns:
            overlays.append(base.mark_line().encode(y=alt.Y(f"{name}:Q"), tooltip=[alt.Tooltip('date:T'), alt.Tooltip(f'{name}:Q')]).transform_fold([name], as_=['indicator','value']).encode(y='value:Q'))
    # simpler approach - add each overlay explicitly for clarity
    overlay_chart = chart
    if "sma20" in df.columns:
        overlay_chart = overlay_chart + base.mark_line(strokeDash=[5,2]).encode(y='sma20:Q', tooltip=['date:T','sma20:Q'])
    if "sma50" in df.columns:
        overlay_chart = overlay_chart + base.mark_line(strokeDash=[2,2]).encode(y='sma50:Q', tooltip=['date:T','sma50:Q'])
    if "ema12" in df.columns:
        overlay_chart = overlay_chart + base.mark_line().encode(y='ema12:Q', tooltip=['date:T','ema12:Q'])
    if "ema26" in df.columns:
        overlay_chart = overlay_chart + base.mark_line().encode(y='ema26:Q', tooltip=['date:T','ema26:Q'])

    overlay_chart = overlay_chart.properties(height=360, width='container')

    # RSI panel
    rsi_chart = None
    if "rsi" in df.columns:
        rsi_chart = alt.Chart(df).mark_line().encode(
            x='date:T',
            y='rsi:Q',
            tooltip=['date:T', 'rsi:Q']
        ).properties(height=120, width='container').interactive()

    # MACD panel
    macd_chart = None
    if "macd" in df.columns and "signal" in df.columns:
        macd_chart = alt.Chart(df).mark_line().encode(
            x='date:T',
            y='macd:Q',
            tooltip=['date:T', 'macd:Q']
        ).properties(height=120, width='container').interactive()
        macd_chart = macd_chart + alt.Chart(df).mark_line(color='orange').encode(x='date:T', y='signal:Q')

    # Compose
    components = [overlay_chart]
    if rsi_chart:
        components.append(rsi_chart)
    if macd_chart:
        components.append(macd_chart)

    # Stack using vconcat
    final = alt.vconcat(*components).resolve_scale(x='shared')
    st.altair_chart(final, use_container_width=True)


def render():
    st.title("📈 Charts & Indicators")
    st.write("Enter a symbol to fetch precomputed indicator time-series from backend (backend does calculations).")

    with st.form("symbol_form"):
        symbol = st.text_input("Symbol (e.g. AAPL, BTC-USD)", value="AAPL")
        period = st.selectbox("Period", ["1mo", "3mo", "6mo", "1y", "2y"], index=2)
        submitted = st.form_submit_button("Fetch & Render")

    if not submitted:
        st.info("Submit a symbol to load chart.")
        return

    with st.spinner(f"Fetching series for {symbol} ..."):
        series, cache_source, err = fetch_series(symbol, period=period)
        if err:
            st.error(err)
            return

        if not series:
            st.warning("No series returned from backend.")
            return

        # convert to DataFrame
        df = pd.DataFrame(series)

        # ensure date column is datetime and sorted
        if "date" in df.columns:
            df["date"] = pd.to_datetime(df["date"])
            df = df.sort_values("date")

        # convert numeric columns to floats, safely
        numeric_cols = [c for c in df.columns if c not in ("date",)]
        for c in numeric_cols:
            df[c] = pd.to_numeric(df[c], errors="coerce")

        st.success(f"Loaded {len(df)} rows — cache: {cache_source}")

        # show small preview table
        st.dataframe(df.tail(8), width="stretch")

        # render altair charts
        render_chart(df)
