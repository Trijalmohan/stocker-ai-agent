# ui/pages/history.py
import streamlit as st
import pandas as pd
try:
    from ui.services.api_client import call_backend
except Exception:
    from services.api_client import call_backend

def render():
    st.title("📜 Trade History")
    trace, response, error = call_backend("", intent="executed_orders")
    if error:
        st.error(error)
        return
    orders = response.get("orders", [])
    if not orders:
        st.info("No executed trades yet.")
        return
    df = pd.DataFrame(orders)
    if "timestamp" in df.columns:
        df["timestamp"] = pd.to_datetime(df["timestamp"])
    st.dataframe(df, width='stretch')
    selected = st.selectbox("Select Trade", orders, format_func=lambda o: f"{o.get('side','').upper()} {o.get('qty')} {o.get('symbol')} @ {o.get('price')}")
    if selected:
        st.json(selected)
