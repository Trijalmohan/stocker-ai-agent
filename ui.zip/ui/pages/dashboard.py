# ui/pages/dashboard.py
import os
import streamlit as st
import pandas as pd

# import API client with fallback
try:
    from ui.services.api_client import call_backend
except Exception:
    from services.api_client import call_backend

def load_css():
    theme_path = os.path.join(os.path.dirname(__file__), "..", "theme.css")
    theme_path = os.path.abspath(theme_path)
    if os.path.exists(theme_path):
        with open(theme_path, "r", encoding="utf-8") as f:
            st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

def fetch_portfolio():
    trace, response, error = call_backend(message="show my portfolio", intent="portfolio")
    if error:
        st.error(f"Portfolio error: {error}")
        return []
    return response.get("portfolio", [])

def fetch_pnl():
    trace, response, error = call_backend(message="show my pnl", intent="pnl")
    if error:
        st.error(f"PNL error: {error}")
        return {"realized": 0.0, "unrealized": 0.0}
    return response

def fetch_balance():
    trace, response, error = call_backend(message="show my balance", intent="balance")
    if error:
        st.error(f"Balance error: {error}")
        return 0.0
    return response.get("balance", 0.0)

def compute_totals(positions, pnl, cash_balance):
    total_positions_value = 0.0
    for pos in positions:
        qty = pos.get("quantity") or pos.get("qty") or 0
        mkt = pos.get("market_price") or pos.get("market_price_usd") or 0
        try:
            total_positions_value += float(qty) * float(mkt)
        except Exception:
            pass
    total_equity = cash_balance + total_positions_value
    return {
        "total_equity": total_equity,
        "cash": cash_balance,
        "positions_value": total_positions_value,
        "realized_pnl": pnl.get("realized", 0.0) or 0.0,
        "unrealized_pnl": pnl.get("unrealized", 0.0) or 0.0,
    }

def format_money(value: float) -> str:
    try:
        return f"${float(value):,.2f}"
    except Exception:
        return "$0.00"

def pnl_class(value: float) -> str:
    if value > 0:
        return "pos"
    if value < 0:
        return "neg"
    return "flat"

def render():
    load_css()
    st.title("📊 Stocker AI – Trading Overview")
    st.caption("Your AI-assisted trading cockpit – powered by Gemini + Alpha Vantage + SQLite.")
    positions = fetch_portfolio()
    pnl = fetch_pnl()
    cash = fetch_balance()
    totals = compute_totals(positions, pnl, cash)
    total_equity = totals["total_equity"]
    cash_balance = totals["cash"]
    realized_pnl = totals["realized_pnl"]
    unrealized_pnl = totals["unrealized_pnl"]

    st.markdown('<div class="card-row">', unsafe_allow_html=True)
    st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Total Equity</div>
            <div class="metric-value">{format_money(total_equity)}</div>
            <div class="metric-sub">Cash + invested positions</div>
        </div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Cash Balance</div>
            <div class="metric-value">{format_money(cash_balance)}</div>
            <div class="metric-sub">Available to deploy</div>
        </div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Unrealized PnL</div>
            <div class="metric-value {pnl_class(unrealized_pnl)}">
                {format_money(unrealized_pnl)}
            </div>
            <div class="metric-sub">Open positions performance</div>
        </div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Realized PnL</div>
            <div class="metric-value {pnl_class(realized_pnl)}">
                {format_money(realized_pnl)}
            </div>
            <div class="metric-sub">Closed trades so far</div>
        </div>
    """, unsafe_allow_html=True)
    st.markdown("</div>", unsafe_allow_html=True)

    st.subheader("📌 Open Positions")
    if not positions:
        st.info("You don't have any open positions yet. Try a few paper trades first.")
    else:
        df = pd.DataFrame(positions)
        st.dataframe(df, width='stretch')

    with st.expander("🔍 Debug info (for judging / dev)", expanded=False):
        st.json({"totals": totals, "positions_count": len(positions)})
