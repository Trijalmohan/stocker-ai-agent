# ui/pages/orders.py
import streamlit as st
import pandas as pd
try:
    from ui.services.api_client import call_backend
except Exception:
    from services.api_client import call_backend

def render():
    st.title("📊 Pending Orders")
    st.write("Review signals, pending trades, and execute orders.")

    trace, response, error = call_backend("", intent="pending_orders")
    if error:
        st.error(error)
        return

    orders = response.get("orders", [])
    if not orders:
        st.info("No pending orders.")
        return

    df = pd.DataFrame(orders)
    st.dataframe(df, width='stretch')

    st.write("### 🔨 Execute Trades")
    for order in orders:
        symbol = order.get("symbol")
        qty = order.get("qty")
        price = order.get("price")
        side = order.get("side", "buy")
        btn_label = f"Execute {side.upper()} {qty} {symbol} @ {price}"
        if st.button(btn_label, key=f"exec_{order.get('id')}"):
            intent = "buy_confirm" if side == "buy" else "sell_confirm"
            trace2, resp2, err2 = call_backend("", intent=intent, payload={"symbol": symbol, "qty": qty, "price": price})
            if err2:
                st.error(err2)
            else:
                st.success("Order executed!")
                st.experimental_rerun()
