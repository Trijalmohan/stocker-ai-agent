# ui/services/api_client.py
import os
import requests
from typing import Optional, Tuple, Any

BACKEND_URL = os.getenv("STOCKER_API_URL", "http://127.0.0.1:8000/api/handle")


def call_backend(
    message: str,
    session_id: Optional[str] = None,
    intent: Optional[str] = None,
    payload: Optional[dict] = None,
) -> Tuple[Optional[str], Optional[Any], Optional[str]]:
    """
    Returns (trace_id, response_obj, error_message)
    """
    body = payload.copy() if payload else {}
    if message:
        body["message"] = message
    if session_id:
        body["session_id"] = session_id
    if intent:
        body["intent"] = intent

    try:
        res = requests.post(BACKEND_URL, json=body, timeout=40)
    except Exception as e:
        return None, None, f"Request error: {e}"

    if res.status_code != 200:
        snippet = res.text[:500]
        return None, None, f"Backend HTTP {res.status_code}: {snippet}"

    try:
        data = res.json()
    except Exception as e:
        return None, None, f"Could not parse backend JSON: {e}"

    trace = data.get("trace") or data.get("trace_id")
    response = data.get("response")
    if response is None:
        return trace, None, "Backend returned no data."

    if isinstance(response, dict) and response.get("status") == "error":
        msg = response.get("message") or response.get("error") or "Backend reported an error."
        return trace, None, msg

    return trace, response, None
