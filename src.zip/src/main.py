import os
from dotenv import load_dotenv
from fastapi import FastAPI
from pydantic import BaseModel
from src.utils.logger import new_trace_id, log_event
from src.orchestrator import Orchestrator
from src.database.pending_orders import init_pending_orders_table
from src.database.init import init_db
init_pending_orders_table()
from src.database.executed_orders import init_executed_orders_table
init_executed_orders_table()


load_dotenv()

app = FastAPI(title="STOCKER API Demo")
orch = Orchestrator()

class HandleRequest(BaseModel):
    session_id: str | None = None
    intent: str | None = None
    message: str | None = None
    payload: dict | None = None

@app.post("/api/handle")
async def handle(req: HandleRequest):
    trace = new_trace_id()

    # ---- Safely parse incoming JSON ----
    data = req.dict(exclude_none=True)

    # ---- Determine session ----
    session_id = data.get("session_id") or orch.new_session("guest")

    # ---- Extract intent & payload ----
    intent = data.get("intent")
    payload = data.get("payload", {})

    # ---- Natural language raw text command ----
    if data.get("message") and not payload:
        payload = {"message": data["message"]}

    # ---- Log user event ----
    log_event(trace, session_id, "user", payload)

    # ---- Pass to orchestrator ----
    response = orch.handle(session_id, intent, payload)

    # ---- Log agent response ----
    log_event(trace, session_id, "assistant", response)

    return {
        "trace": trace,
        "session_id": session_id,
        "response": response
    }

@app.get("/")
def root():
    return {"status": "running"}
