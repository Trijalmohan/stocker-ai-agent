# src/services/indicators.py

import yfinance as yf
import pandas as pd
from typing import List, Dict, Any


# ====================================================
# 🔧 Download history helper
# ====================================================
def _download_history(symbol: str, period="6mo", interval="1d") -> pd.DataFrame:
    df = yf.download(symbol, period=period, interval=interval, progress=False)
    df = df.dropna()
    if len(df) == 0:
        raise ValueError(f"No historical data found for {symbol}")
    return df


# ====================================================
# 🔧 Indicator functions
# ====================================================
def _ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False).mean()


def _rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    gain = (delta.where(delta > 0, 0)).rolling(period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(period).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))


def _bollinger(series: pd.Series, period: int = 20, std_dev: float = 2.0):
    mid = series.rolling(period).mean()
    std = series.rolling(period).std()
    upper = mid + std_dev * std
    lower = mid - std_dev * std
    return mid, upper, lower


def _macd(series: pd.Series):
    ema12 = _ema(series, 12)
    ema26 = _ema(series, 26)
    macd = ema12 - ema26
    signal = macd.ewm(span=9, adjust=False).mean()
    hist = macd - signal
    return macd, signal, hist


def _atr(df: pd.DataFrame, period: int = 14):
    high = df["High"]
    low = df["Low"]
    close = df["Close"]

    tr = pd.concat(
        [
            high - low,
            (high - close.shift()).abs(),
            (low - close.shift()).abs(),
        ],
        axis=1,
    ).max(axis=1)

    return tr.rolling(period).mean()


# ====================================================
# 🔧 Safe cleaner (removes NaN / inf for JSON)
# ====================================================
def _clean(x):
    if x is None:
        return None
    if isinstance(x, float):
        if x != x:  # NaN
            return None
        if x in (float("inf"), float("-inf")):
            return None
        return float(x)
    try:
        v = float(x)
        if v != v or v in (float("inf"), float("-inf")):
            return None
        return v
    except:
        return None


# ====================================================
# 📌 MAIN: Chart series for frontend
# ====================================================
def get_indicator_series(symbol: str, period="6mo") -> List[Dict[str, Any]]:
    df = _download_history(symbol, period)
    close = df["Close"]

    sma20 = close.rolling(20).mean()
    sma50 = close.rolling(50).mean()
    ema12 = _ema(close, 12)
    ema26 = _ema(close, 26)
    bb_mid, bb_upper, bb_lower = _bollinger(close, 20)
    rsi = _rsi(close)
    macd, sig, hist = _macd(close)

    out = []

    for idx in df.index:
        out.append({
            "date": idx.strftime("%Y-%m-%d"),
            "close": _clean(close.loc[idx]),
            "sma20": _clean(sma20.loc[idx]),
            "sma50": _clean(sma50.loc[idx]),
            "ema12": _clean(ema12.loc[idx]),
            "ema26": _clean(ema26.loc[idx]),
            "bb_mid": _clean(bb_mid.loc[idx]),
            "bb_upper": _clean(bb_upper.loc[idx]),
            "bb_lower": _clean(bb_lower.loc[idx]),
            "rsi": _clean(rsi.loc[idx]),
            "macd": _clean(macd.loc[idx]),
            "signal": _clean(sig.loc[idx]),
            "histogram": _clean(hist.loc[idx]),
        })

    # Return last 120 candles max
    if len(out) > 120:
        out = out[-120:]

    return out


# ====================================================
# 📌 MAIN: Latest indicator summary
# ====================================================
def get_indicators(symbol: str, period="6mo") -> Dict[str, Any]:
    df = _download_history(symbol, period)
    close = df["Close"]

    sma20 = close.rolling(20).mean()
    sma50 = close.rolling(50).mean()
    ema12 = _ema(close, 12)
    ema26 = _ema(close, 26)
    bb_mid, bb_upper, bb_lower = _bollinger(close)
    rsi = _rsi(close)
    macd, sig, hist = _macd(close)
    atr = _atr(df)

    latest = df.index[-1]

    return {
        "symbol": symbol,
        "latest_price": _clean(close.loc[latest]),
        "trend": {
            "sma20": _clean(sma20.loc[latest]),
            "sma50": _clean(sma50.loc[latest]),
            "ema12": _clean(ema12.loc[latest]),
            "ema26": _clean(ema26.loc[latest]),
        },
        "momentum": {
            "rsi": _clean(rsi.loc[latest]),
            "macd": _clean(macd.loc[latest]),
            "signal": _clean(sig.loc[latest]),
            "histogram": _clean(hist.loc[latest]),
        },
        "bollinger": {
            "upper": _clean(bb_upper.loc[latest]),
            "lower": _clean(bb_lower.loc[latest]),
            "mid": _clean(bb_mid.loc[latest]),
        },
        "volatility": {
            "atr": _clean(atr.loc[latest])
        }
    }
