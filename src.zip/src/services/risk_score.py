# src/services/risk_score.py
import math

def calculate_risk(price: float | None, volatility: float | None) -> dict:
    """
    Very simple risk assessment stub.
    Later we will add Beta, Sharpe Ratio, Earnings Data, etc.
    """

    if price is None or volatility is None:
        return {
            "risk_score": None,
            "level": "unknown",
            "reason": "Missing data"
        }

    # Simple risk calculation
    score = volatility * 10

    if score < 20:
        level = "Low"
    elif score < 40:
        level = "Medium"
    else:
        level = "High"

    return {
        "risk_score": round(score, 2),
        "level": level,
        "reason": f"Calculated from volatility={volatility}"
    }
