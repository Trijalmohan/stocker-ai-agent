# src/services/backtest.py

import pandas as pd
from src.services.market_data import get_stock_candles, add_indicators


def sma_crossover_strategy(df):
    df = df.copy()
    df["position"] = 0
    df["position"] = df["SMA50"] > df["SMA200"]

    df["signal"] = df["position"].diff()

    return df


def backtest(symbol="AAPL"):
    df = get_stock_candles(symbol)
    df = add_indicators(df)

    if df.empty or "SMA50" not in df:
        return {"error": "Insufficient data for backtest."}

    df = sma_crossover_strategy(df)

    initial_balance = 10000
    balance = initial_balance
    shares = 0

    for idx, row in df.iterrows():
        if row["signal"] == 1:  # buy
            shares = balance / row["close"]
            balance = 0

        elif row["signal"] == -1 and shares > 0:  # sell
            balance = shares * row["close"]
            shares = 0

    if shares > 0:
        balance = shares * df["close"].iloc[-1]

    return {
        "initial_balance": initial_balance,
        "final_balance": round(balance, 2),
        "profit": round(balance - initial_balance, 2)
    }
