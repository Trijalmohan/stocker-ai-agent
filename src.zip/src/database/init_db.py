# src/database/init_db.py

import sqlite3
import os

DB_PATH = os.path.join("src", "database", "stocker.db")

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # ----------------------
    # Positions table
    # ----------------------
    c.execute("""
        CREATE TABLE IF NOT EXISTS positions (
            symbol TEXT PRIMARY KEY,
            quantity REAL,
            avg_price REAL,
            market_price REAL,
            unrealized_pnl REAL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # ----------------------
    # Balance table
    # ----------------------
    c.execute("""
        CREATE TABLE IF NOT EXISTS balance (
            id INTEGER PRIMARY KEY,
            amount REAL
        )
    """)

    # Seed initial balance IF empty
    c.execute("SELECT COUNT(*) FROM balance")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO balance (id, amount) VALUES (1, 10000.0)")

    # ----------------------
    # Executed trades
    # ----------------------
    c.execute("""
        CREATE TABLE IF NOT EXISTS executed_orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            symbol TEXT,
            qty REAL,
            price REAL,
            side TEXT,
            recommendation TEXT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # ----------------------
    # Pending orders
    # ----------------------
    c.execute("""
        CREATE TABLE IF NOT EXISTS pending_orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            symbol TEXT,
            qty REAL,
            price REAL,
            side TEXT,
            recommendation TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.commit()
    conn.close()
    print("Database initialized successfully!")

if __name__ == "__main__":
    init_db()
