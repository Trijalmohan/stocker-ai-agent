# src/database/init.py

from src.database.positions import init_positions_table
from src.database.balance import init_balance_table
from src.database.logs import init_logs_table
from src.database.pending_orders import init_pending_orders_table
from src.database.executed_orders import init_executed_orders_table


def init_db():
    print("🔧 Initializing StockerAI Database...")

    init_positions_table()
    init_balance_table()
    init_logs_table()
    init_pending_orders_table()
    init_executed_orders_table()

    print("✅ Database Ready!")
