# src/database/connection.py
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "stocker.db")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    return conn


def init_db():
    conn = get_db()
    cursor = conn.cursor()
    # ---- Orders / Trades history ----
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id   TEXT,
            symbol       TEXT NOT NULL,
            side         TEXT NOT NULL,           -- BUY / SELL
            qty          REAL NOT NULL,
            price        REAL NOT NULL,
            status       TEXT NOT NULL DEFAULT 'executed',
            source       TEXT,                    -- e.g. 'api', 'ui', 'simulation'
            meta         TEXT,                    -- JSON string with extra info
            created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    # --- Portfolio Table ---
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS portfolio (
        symbol TEXT PRIMARY KEY,
        quantity REAL NOT NULL,
        avg_price REAL NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # --- Balance Table ---
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS balance (
        id INTEGER PRIMARY KEY,
        total REAL NOT NULL
    )
    """)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS balance (
        id INTEGER PRIMARY KEY,
        total REAL DEFAULT 0
    )
    """)

    # Insert default starting balance if missing
    cursor.execute("""
    INSERT OR IGNORE INTO balance (id, total)
    VALUES (1, 10000.00)
    """)

    # --- Transaction History ---
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        symbol TEXT NOT NULL,
        qty REAL NOT NULL,
        price REAL NOT NULL,
        side TEXT CHECK(side IN ('BUY', 'SELL')),
        pnl REAL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # --- Conversation Memory Table ---
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS conversation_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT,
        role TEXT,
        message TEXT,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    conn.commit()
    conn.close()
if __name__ == "__main__":
    init_db()
