import sqlite3
from src.database.connection import get_db
from src.services.market_data import get_stock_price

# BUY
def add_or_update_position(symbol: str, quantity: float, price: float):
    conn = get_db()
    cursor = conn.cursor()
    symbol = symbol.upper()

    cursor.execute("SELECT quantity, avg_price FROM portfolio WHERE symbol = ?", (symbol,))
    existing = cursor.fetchone()

    if not existing:
        cursor.execute("""
            INSERT INTO portfolio (symbol, quantity, avg_price)
            VALUES (?, ?, ?)
        """, (symbol, quantity, price))
    else:
        old_qty, old_price = existing
        new_qty = old_qty + quantity
        new_avg = ((old_price * old_qty) + (price * quantity)) / new_qty

        cursor.execute("""
            UPDATE portfolio
            SET quantity = ?, avg_price = ?, updated_at = CURRENT_TIMESTAMP
            WHERE symbol = ?
        """, (new_qty, new_avg, symbol))

    # Log buy
    cursor.execute("""
        INSERT INTO transactions (symbol, qty, price, side, pnl)
        VALUES (?, ?, ?, 'BUY', NULL)
    """, (symbol, quantity, price))

    conn.commit()
    conn.close()
    return True



# SELL
def sell_position(symbol: str, qty: float, price: float):
    conn = get_db()
    cursor = conn.cursor()
    symbol = symbol.upper()

    cursor.execute("SELECT quantity, avg_price FROM portfolio WHERE symbol = ?", (symbol,))
    row = cursor.fetchone()

    if not row:
        return {"error": "No position exists for this stock"}

    current_qty, avg_price = row

    if qty > current_qty:
        return {"error": "Not enough shares to sell"}

    new_qty = current_qty - qty
    realized_pnl = (price - avg_price) * qty

    if new_qty == 0:
        cursor.execute("DELETE FROM portfolio WHERE symbol = ?", (symbol,))
    else:
        cursor.execute("""
            UPDATE portfolio
            SET quantity = ?, updated_at = CURRENT_TIMESTAMP
            WHERE symbol = ?
        """, (new_qty, symbol))

    # Log transaction
    cursor.execute("""
        INSERT INTO transactions (symbol, qty, price, side, pnl)
        VALUES (?, ?, ?, 'SELL', ?)
    """, (symbol, qty, price, realized_pnl))

    conn.commit()
    conn.close()

    return {
        "symbol": symbol,
        "quantity_sold": qty,
        "remaining": new_qty,
        "realized_pnl": realized_pnl,
        "proceeds": qty * price
    }



# PORTFOLIO VIEW
def get_positions():
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("SELECT symbol, quantity, avg_price, updated_at FROM portfolio")
    rows = cursor.fetchall()

    results = []

    for symbol, qty, avg_price, updated_at in rows:
        data = get_stock_price(symbol)
        market_data = get_stock_price(symbol)
        market_price = market_data.get("price") if isinstance(market_data, dict) else None


        unrealized = (market_price - avg_price) * qty if market_price else None

        results.append({
            "symbol": symbol,
            "quantity": qty,
            "avg_price": avg_price,
            "market_price": market_price,
            "unrealized_pnl": unrealized,
            "updated_at": updated_at
        })

    conn.close()
    return results



# PNL HELPERS
def get_realized_pnl():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT SUM(pnl) FROM transactions WHERE side='SELL'")
    result = cursor.fetchone()[0]
    conn.close()
    return result or 0.0

def get_unrealized_pnl():
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("SELECT symbol, quantity, avg_price FROM portfolio")
    rows = cursor.fetchall()
    conn.close()

    total = 0
    for symbol, qty, avg_price in rows:
        data = get_stock_price(symbol)

        # Handle case where API returns a string
        if not isinstance(data, dict) or "price" not in data:
            continue

        current_price = data["price"]
        total += (current_price - avg_price) * qty

    return total

