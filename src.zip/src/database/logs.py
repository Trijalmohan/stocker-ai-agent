# src/database/logs.py
from src.database.connection import get_db


def init_logs_table():
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            trace_id TEXT,
            event TEXT,
            detail TEXT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.commit()
    conn.close()


def save_log(trace_id, event, detail):
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO logs (trace_id, event, detail)
        VALUES (?, ?, ?)
    """, (trace_id, event, detail))

    conn.commit()
    conn.close()
