import sqlite3
from src.database.connection import get_db

def save_message(session_id: str, role: str, message: str):
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO conversation_history (session_id, role, message)
        VALUES (?, ?, ?)
    """, (session_id, role, message))

    conn.commit()
    conn.close()


def get_history(session_id: str, limit: int = 20):
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT role, message FROM conversation_history
        WHERE session_id=?
        ORDER BY id DESC
        LIMIT ?
    """, (session_id, limit))

    rows = cursor.fetchall()
    conn.close()

    # Convert to prompt format
    return [{"role": r[0], "message": r[1]} for r in rows[::-1]]
