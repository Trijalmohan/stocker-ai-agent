# src/database/executed_orders.py
from src.database.connection import get_db


def init_executed_orders_table():
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS executed_orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            symbol TEXT NOT NULL,
            qty REAL NOT NULL,
            price REAL NOT NULL,
            side TEXT NOT NULL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.commit()
    conn.close()


def save_executed_order(session_id, symbol, qty, price, side):
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO executed_orders (session_id, symbol, qty, price, side)
        VALUES (?, ?, ?, ?, ?)
    """, (session_id, symbol, qty, price, side))

    conn.commit()
    conn.close()


def get_executed_orders(session_id):
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM executed_orders WHERE session_id = ?", (session_id,))
    rows = cursor.fetchall()

    conn.close()
    return rows
