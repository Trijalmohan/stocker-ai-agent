# src/database/balance.py
import sqlite3
from src.database.connection import get_db


def init_balance_table():
    """
    Creates the balance table with a single row (id=1) if not exists.
    """
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS balance (
            id INTEGER PRIMARY KEY,
            total REAL NOT NULL DEFAULT 0
        )
    """)

    # Ensure at least one row exists
    cursor.execute("SELECT COUNT(*) FROM balance")
    count = cursor.fetchone()[0]

    if count == 0:
        cursor.execute("INSERT INTO balance (id, total) VALUES (1, 0.0)")

    conn.commit()
    conn.close()


def get_balance():
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("SELECT total FROM balance WHERE id = 1")
    row = cursor.fetchone()

    conn.close()
    return row[0] if row else 0.0


def update_balance(new_balance: float):
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("UPDATE balance SET total = ? WHERE id = 1", (new_balance,))
    conn.commit()
    conn.close()


def deposit(amount: float):
    balance = get_balance()
    new_balance = balance + amount
    update_balance(new_balance)
    return new_balance
