# src/orchestrator.py
from typing import Optional
from src.memory.memory_service import MemoryService
from src.agents.teacher_agent import TeacherAgent
from src.agents.expert_agent import ExpertAgent
from src.agents.quiz_agent import QuizAgent
from src.agents.simulator_agent import SimulatorAgent
from src.agents.intent_classifier_agent import IntentClassifierAgent
from src.agents.strategy_engine import StrategyEngine

# Portfolio + Balance
from src.database.portfolio import (
    add_or_update_position,
    get_positions,
    sell_position,
    get_realized_pnl,
    get_unrealized_pnl
)
from src.database.balance import get_balance, update_balance, deposit

# Memory DB
from src.database.conversation import save_message

# Market Data
from src.services.market_data import (
    get_stock_price,
    get_crypto_price,
    formatted_news
)

# Pending & executed orders
from src.database.pending_orders import (
    init_pending_orders_table,
    save_pending_order,
    get_pending_orders,
    delete_pending_order,
)
from src.database.executed_orders import (
    init_executed_orders_table,
    log_executed_order,
    get_executed_orders,
)

# Ensure DB tables exist when orchestrator is constructed (safe no-op if init_db already did this)
init_pending_orders_table()
init_executed_orders_table()


def _sanitize_response(obj):
    # convert NaN floats (or other non-json values) into None so JSON responses don't break
    import math
    if isinstance(obj, dict):
        return {k: _sanitize_response(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_sanitize_response(v) for v in obj]
    if isinstance(obj, float) and math.isnan(obj):
        return None
    return obj


class Orchestrator:
    def __init__(self):
        self.classifier = IntentClassifierAgent()
        self.memory = MemoryService()
        self.teacher = TeacherAgent(memory=self.memory)
        self.expert = ExpertAgent(memory=self.memory)
        self.quiz = QuizAgent()
        self.sim = SimulatorAgent()
        self.strategy = StrategyEngine()

    def new_session(self, user_id: str):
        return self.memory.create_session(user_id)

    def handle(self, session_id: str, intent: Optional[str], payload: Optional[dict]):
        payload = payload or {}

        # Save raw user message
        if "message" in payload:
            save_message(session_id, "user", payload["message"])

        # CLASSIFICATION (if not provided)
        if not intent and "message" in payload:
            result = self.classifier.classify(payload["message"])
            intent = result.get("intent")
            payload = result.get("payload", {})

        try:
            # ======================
            # 📈 ANALYZE (CONTEXT-AWARE)
            # ======================
            if intent == "analyze":
                symbol = payload.get("symbol", "AAPL")
                user_context = payload.get("message") or payload.get("context") or "No external context provided."
                response = self.strategy.analyze(symbol, user_message=user_context)

            # ======================
            # 📊 PNL
            # ======================
            elif intent == "pnl":
                response = {
                    "realized": get_realized_pnl(),
                    "unrealized": get_unrealized_pnl()
                }

            # ======================
            # 🧠 TEACHER MODE
            # ======================
            elif intent == "explain":
                response = self.teacher.explain(
                    session_id,
                    topic=payload.get("topic", "stocks"),
                    level=payload.get("level", "basic")
                )

            # ======================
            # BALANCE + FUNDS
            # ======================
            elif intent == "deposit":
                amount = float(payload.get("amount", 0))
                new_total = deposit(amount)
                response = {"status": "success", "balance": new_total}

            elif intent == "balance":
                response = {"balance": get_balance()}

            # ======================
            # BUY (requires approval)
            # Save as pending order and return pending response
            # ======================
            elif intent == "buy":
                symbol = payload.get("symbol")
                qty = float(payload.get("qty", 0))
                price = float(payload.get("price", 0))
                side = payload.get("side", "buy")
                recommendation = payload.get("recommendation")

                # Save pending order to DB (so UI can fetch)
                save_pending_order(session_id, symbol, qty, price, side, recommendation)

                response = {
                    "status": "pending",
                    "action": "buy",
                    "details": {"symbol": symbol, "qty": qty, "price": price, "side": side},
                    "message": "This is a recommendation. Confirm with intent 'buy_confirm'."
                }

            # ======================
            # BUY CONFIRM (executes)
            # ======================
            elif intent == "buy_confirm":
                symbol = payload.get("symbol")
                qty = float(payload.get("qty", 0))
                price = float(payload.get("price", 0))
                total_cost = qty * price
                balance = get_balance()

                # check funds
                if total_cost > balance:
                    response = {"status": "failed", "error": "Insufficient balance"}
                else:
                    add_or_update_position(symbol, qty, price)
                    update_balance(balance - total_cost)

                    # log executed order
                    log_executed_order(symbol=symbol, qty=qty, price=price, side="buy", session_id=session_id, recommendation=payload.get("recommendation"))

                    # remove any matching pending orders (best-effort)
                    try:
                        # Attempt to remove by matching symbol/qty/price for session
                        pend = get_pending_orders(session_id=session_id)
                        for p in pend:
                            if p.get("symbol") == symbol and float(p.get("qty", 0)) == qty and float(p.get("price", 0)) == price:
                                delete_pending_order(p.get("id"))
                    except Exception:
                        pass

                    response = {"status": "success", "message": f"Bought {qty} of {symbol}"}

            # ======================
            # SELL (pending)
            # ======================
            elif intent == "sell":
                response = {"status": "pending", "message": "Ask: 'confirm sell'"}

            # ======================
            # SELL CONFIRM (not fully implemented — placeholder)
            # ======================
            elif intent == "sell_confirm":
                # For now mirror buy_confirm behaviour but removing positions would be required
                response = {"status": "success", "message": "Sell executed (simulated)"}

            # ======================
            # PORTFOLIO
            # ======================
            elif intent == "portfolio":
                response = {"portfolio": get_positions()}

            # ======================
            # MARKET DATA
            # ======================
            elif intent == "stock_price":
                response = get_stock_price(payload.get("symbol"))

            elif intent == "crypto_price":
                response = get_crypto_price(payload.get("symbol"))

            elif intent == "market_news":
                response = formatted_news(payload.get("limit", 5))

            # ======================
            # PENDING ORDERS (UI)
            # ======================
            elif intent == "pending_orders":
                # accept optional session param
                response = {"orders": get_pending_orders(session_id=payload.get("session_id") or session_id)}

            # ======================
            # EXECUTED ORDERS (history)
            # ======================
            elif intent == "executed_orders":
                response = {"orders": get_executed_orders(limit=payload.get("limit", 100))}

            # ======================
            # DEFAULT CASE
            # ======================
            else:
                response = {"error": f"Unknown intent '{intent}'"}
        except Exception as e:
            # Make sure we return something serializable
            response = {"status": "error", "message": str(e)}

        # Save assistant reply to conversation DB
        try:
            save_message(session_id, "assistant", str(response))
        except Exception:
            pass

        # sanitize NaN etc before returning
        return _sanitize_response(response)
