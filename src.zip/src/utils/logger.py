import logging
import uuid
from src.database.logs import save_log

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[logging.StreamHandler()]
)

def new_trace_id():
    return str(uuid.uuid4())

def log_event(event_type: str, trace_id: str, message: str, data=None):
    logging.info(f"[{event_type}] trace={trace_id} | {message} | data={data}")
    save_log(event_type, trace_id, message, str(data))
