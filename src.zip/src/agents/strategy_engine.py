# src/agents/strategy_engine.py

from google import genai
import os

from src.services.market_data import get_stock_price
from src.services.indicators import get_indicators
from src.services.risk_score import calculate_risk


class StrategyEngine:
    def __init__(self):
        self.client = genai.Client(api_key=os.getenv("GOOGLE_API_KEY"))
        self.model = "models/gemini-2.5-flash"

    def analyze(self, symbol: str, user_message: str = None):
        symbol = symbol.upper()

        # Fallback if no user context provided
        if not user_message:
            user_message = "User did not provide macro or reasoning context."

        # Fetch price
        price_data = get_stock_price(symbol)

        price = price_data.get("price")

        # Indicators
        indicators = get_indicators(symbol)

        # Risk score
        volatility = indicators.get("volatility")
        risk = calculate_risk(price, volatility)

        # Context-aware prompt
        prompt = f"""
You are a financial analyst combining:
- Technical indicators
- Sentiment context
- Macro reasoning provided by the user

User Question / Context:
{user_message}

Symbol: {symbol}
Price: {price}

Technical Indicators:
{indicators}

Risk Score (0-100):
{risk}

Rules:
- DO NOT assume user wants to execute a trade.
- Provide a recommendation (Buy / Sell / Hold / Watch)
- Justify using BOTH technical + user macro context
- Be concise and analytical
- Respond in valid JSON only.

Response format:
{{
  "summary": "...",
  "context_analysis": "...",
  "technical_analysis": "...",
  "macro_analysis": "...",
  "recommendation": "...",
  "confidence": 0-100,
  "price_target": number
}}
"""

        result = self.client.models.generate_content(
            model=self.model,
            contents=prompt
        )

        return {
            "status": "ok",
            "symbol": symbol,
            "price": price,
            "indicators": indicators,
            "risk": risk,
            "analysis": result.text.strip(),
            "action": "To execute: say 'approve trade'"
        }
